﻿namespace Digital_Community_Medicine___Health_Service_Management_System
{
    partial class FrmPatientDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.buttonFindDoctor = new System.Windows.Forms.Button();
            this.buttonMyAppointments = new System.Windows.Forms.Button();
            this.buttonMedicalHistory = new System.Windows.Forms.Button();
            this.buttonNearbyClinics = new System.Windows.Forms.Button();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.btnMyProfile = new System.Windows.Forms.Button();
            this.btnAppointmentHistory = new System.Windows.Forms.Button();
            this.btnPrescriptions = new System.Windows.Forms.Button();
            this.btnPayments = new System.Windows.Forms.Button();
            this.btnReviews = new System.Windows.Forms.Button();
            this.btnBuyMedicine = new System.Windows.Forms.Button();
            this.btnMyOrders = new System.Windows.Forms.Button();
            this.btnEmergency = new System.Windows.Forms.Button();
            this.btnFollowUps = new System.Windows.Forms.Button();
            this.btnComplaint = new System.Windows.Forms.Button();
            this.btnDiagnosticLab = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(335, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome";
            // 
            // buttonFindDoctor
            // 
            this.buttonFindDoctor.Location = new System.Drawing.Point(85, 122);
            this.buttonFindDoctor.Name = "buttonFindDoctor";
            this.buttonFindDoctor.Size = new System.Drawing.Size(130, 65);
            this.buttonFindDoctor.TabIndex = 1;
            this.buttonFindDoctor.Text = "Find Doctor";
            this.buttonFindDoctor.UseVisualStyleBackColor = true;
            this.buttonFindDoctor.Click += new System.EventHandler(this.buttonFindDoctor_Click);
            // 
            // buttonMyAppointments
            // 
            this.buttonMyAppointments.Location = new System.Drawing.Point(85, 210);
            this.buttonMyAppointments.Name = "buttonMyAppointments";
            this.buttonMyAppointments.Size = new System.Drawing.Size(130, 65);
            this.buttonMyAppointments.TabIndex = 2;
            this.buttonMyAppointments.Text = "My Appointments";
            this.buttonMyAppointments.UseVisualStyleBackColor = true;
            this.buttonMyAppointments.Click += new System.EventHandler(this.buttonMyAppointments_Click);
            // 
            // buttonMedicalHistory
            // 
            this.buttonMedicalHistory.Location = new System.Drawing.Point(270, 206);
            this.buttonMedicalHistory.Name = "buttonMedicalHistory";
            this.buttonMedicalHistory.Size = new System.Drawing.Size(130, 65);
            this.buttonMedicalHistory.TabIndex = 3;
            this.buttonMedicalHistory.Text = "Medical History";
            this.buttonMedicalHistory.UseVisualStyleBackColor = true;
            this.buttonMedicalHistory.Click += new System.EventHandler(this.buttonMedicalHistory_Click);
            // 
            // buttonNearbyClinics
            // 
            this.buttonNearbyClinics.Location = new System.Drawing.Point(270, 130);
            this.buttonNearbyClinics.Name = "buttonNearbyClinics";
            this.buttonNearbyClinics.Size = new System.Drawing.Size(130, 57);
            this.buttonNearbyClinics.TabIndex = 4;
            this.buttonNearbyClinics.Text = "Nearby Clinics";
            this.buttonNearbyClinics.UseVisualStyleBackColor = true;
            this.buttonNearbyClinics.Click += new System.EventHandler(this.buttonNearbyClinics_Click);
            // 
            // buttonLogout
            // 
            this.buttonLogout.Location = new System.Drawing.Point(440, 387);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(130, 51);
            this.buttonLogout.TabIndex = 5;
            this.buttonLogout.Text = "Logout";
            this.buttonLogout.UseVisualStyleBackColor = true;
            this.buttonLogout.Click += new System.EventHandler(this.buttonLogout_Click);
            // 
            // btnMyProfile
            // 
            this.btnMyProfile.Location = new System.Drawing.Point(85, 45);
            this.btnMyProfile.Name = "btnMyProfile";
            this.btnMyProfile.Size = new System.Drawing.Size(130, 57);
            this.btnMyProfile.TabIndex = 6;
            this.btnMyProfile.Text = "My Profile";
            this.btnMyProfile.UseVisualStyleBackColor = true;
            this.btnMyProfile.Click += new System.EventHandler(this.btnMyProfile_Click);
            // 
            // btnAppointmentHistory
            // 
            this.btnAppointmentHistory.Location = new System.Drawing.Point(85, 287);
            this.btnAppointmentHistory.Name = "btnAppointmentHistory";
            this.btnAppointmentHistory.Size = new System.Drawing.Size(130, 65);
            this.btnAppointmentHistory.TabIndex = 7;
            this.btnAppointmentHistory.Text = "Appointment History";
            this.btnAppointmentHistory.UseVisualStyleBackColor = true;
            this.btnAppointmentHistory.Click += new System.EventHandler(this.btnAppointmentHistory_Click);
            // 
            // btnPrescriptions
            // 
            this.btnPrescriptions.Location = new System.Drawing.Point(270, 45);
            this.btnPrescriptions.Name = "btnPrescriptions";
            this.btnPrescriptions.Size = new System.Drawing.Size(130, 70);
            this.btnPrescriptions.TabIndex = 8;
            this.btnPrescriptions.Text = "Prescriptions";
            this.btnPrescriptions.UseVisualStyleBackColor = true;
            this.btnPrescriptions.Click += new System.EventHandler(this.btnPrescriptions_Click);
            // 
            // btnPayments
            // 
            this.btnPayments.Location = new System.Drawing.Point(270, 287);
            this.btnPayments.Name = "btnPayments";
            this.btnPayments.Size = new System.Drawing.Size(130, 65);
            this.btnPayments.TabIndex = 9;
            this.btnPayments.Text = "Payments";
            this.btnPayments.UseVisualStyleBackColor = true;
            this.btnPayments.Click += new System.EventHandler(this.btnPayments_Click);
            // 
            // btnReviews
            // 
            this.btnReviews.Location = new System.Drawing.Point(481, 210);
            this.btnReviews.Name = "btnReviews";
            this.btnReviews.Size = new System.Drawing.Size(117, 57);
            this.btnReviews.TabIndex = 10;
            this.btnReviews.Text = "Reviews";
            this.btnReviews.UseVisualStyleBackColor = true;
            this.btnReviews.Click += new System.EventHandler(this.btnReviews_Click);
            // 
            // btnBuyMedicine
            // 
            this.btnBuyMedicine.Location = new System.Drawing.Point(481, 45);
            this.btnBuyMedicine.Name = "btnBuyMedicine";
            this.btnBuyMedicine.Size = new System.Drawing.Size(117, 70);
            this.btnBuyMedicine.TabIndex = 11;
            this.btnBuyMedicine.Text = "Buy Medicine";
            this.btnBuyMedicine.UseVisualStyleBackColor = true;
            this.btnBuyMedicine.Click += new System.EventHandler(this.btnBuyMedicine_Click);
            // 
            // btnMyOrders
            // 
            this.btnMyOrders.Location = new System.Drawing.Point(481, 130);
            this.btnMyOrders.Name = "btnMyOrders";
            this.btnMyOrders.Size = new System.Drawing.Size(117, 57);
            this.btnMyOrders.TabIndex = 12;
            this.btnMyOrders.Text = "My Orders";
            this.btnMyOrders.UseVisualStyleBackColor = true;
            this.btnMyOrders.Click += new System.EventHandler(this.btnMyOrders_Click);
            // 
            // btnEmergency
            // 
            this.btnEmergency.Location = new System.Drawing.Point(481, 287);
            this.btnEmergency.Name = "btnEmergency";
            this.btnEmergency.Size = new System.Drawing.Size(117, 65);
            this.btnEmergency.TabIndex = 13;
            this.btnEmergency.Text = "Emergency";
            this.btnEmergency.UseVisualStyleBackColor = true;
            this.btnEmergency.Click += new System.EventHandler(this.btnEmergency_Click);
            // 
            // btnFollowUps
            // 
            this.btnFollowUps.Location = new System.Drawing.Point(208, 387);
            this.btnFollowUps.Name = "btnFollowUps";
            this.btnFollowUps.Size = new System.Drawing.Size(107, 51);
            this.btnFollowUps.TabIndex = 14;
            this.btnFollowUps.Text = "Upcoming Follow-ups";
            this.btnFollowUps.UseVisualStyleBackColor = true;
            this.btnFollowUps.Click += new System.EventHandler(this.btnFollowUps_Click);
            // 
            // btnComplaint
            // 
            this.btnComplaint.Location = new System.Drawing.Point(653, 130);
            this.btnComplaint.Name = "btnComplaint";
            this.btnComplaint.Size = new System.Drawing.Size(105, 64);
            this.btnComplaint.TabIndex = 15;
            this.btnComplaint.Text = "Complaint";
            this.btnComplaint.UseVisualStyleBackColor = true;
            this.btnComplaint.Click += new System.EventHandler(this.btnComplaint_Click);
            // 
            // btnDiagnosticLab
            // 
            this.btnDiagnosticLab.Location = new System.Drawing.Point(653, 248);
            this.btnDiagnosticLab.Name = "btnDiagnosticLab";
            this.btnDiagnosticLab.Size = new System.Drawing.Size(105, 64);
            this.btnDiagnosticLab.TabIndex = 16;
            this.btnDiagnosticLab.Text = "DiagnosticLab";
            this.btnDiagnosticLab.UseVisualStyleBackColor = true;
            this.btnDiagnosticLab.Click += new System.EventHandler(this.btnDiagnosticLab_Click);
            // 
            // FrmPatientDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDiagnosticLab);
            this.Controls.Add(this.btnComplaint);
            this.Controls.Add(this.btnFollowUps);
            this.Controls.Add(this.btnEmergency);
            this.Controls.Add(this.btnMyOrders);
            this.Controls.Add(this.btnBuyMedicine);
            this.Controls.Add(this.btnReviews);
            this.Controls.Add(this.btnPayments);
            this.Controls.Add(this.btnPrescriptions);
            this.Controls.Add(this.btnAppointmentHistory);
            this.Controls.Add(this.btnMyProfile);
            this.Controls.Add(this.buttonLogout);
            this.Controls.Add(this.buttonNearbyClinics);
            this.Controls.Add(this.buttonMedicalHistory);
            this.Controls.Add(this.buttonMyAppointments);
            this.Controls.Add(this.buttonFindDoctor);
            this.Controls.Add(this.label1);
            this.Name = "FrmPatientDashboard";
            this.Text = "FrmPatientDashboard";
            this.Load += new System.EventHandler(this.FrmPatientDashboard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonFindDoctor;
        private System.Windows.Forms.Button buttonMyAppointments;
        private System.Windows.Forms.Button buttonMedicalHistory;
        private System.Windows.Forms.Button buttonNearbyClinics;
        private System.Windows.Forms.Button buttonLogout;
        private System.Windows.Forms.Button btnMyProfile;
        private System.Windows.Forms.Button btnAppointmentHistory;
        private System.Windows.Forms.Button btnPrescriptions;
        private System.Windows.Forms.Button btnPayments;
        private System.Windows.Forms.Button btnReviews;
        private System.Windows.Forms.Button btnBuyMedicine;
        private System.Windows.Forms.Button btnMyOrders;
        private System.Windows.Forms.Button btnEmergency;
        private System.Windows.Forms.Button btnFollowUps;
        private System.Windows.Forms.Button btnComplaint;
        private System.Windows.Forms.Button btnDiagnosticLab;
    }
}